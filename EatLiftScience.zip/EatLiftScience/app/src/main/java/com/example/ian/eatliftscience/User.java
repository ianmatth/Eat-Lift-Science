package com.example.ian.eatliftscience;

/**
 * Created by Ian on 12/3/2017.
 */


public class User {

    public String email;

    public String password;

    public Float weight;

    public Float bodyFat;

    public Float prev_weight;

    public Float prev_bodyFat;
}






